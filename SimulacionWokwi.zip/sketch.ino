
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include "decision_tree.h"
#include "imu_features.h"

#define LED_PIN 18
#define BUTTON_PIN 25

#define MQTT_HOST "broker.hivemq.com"
#define MQTT_PORT 1883

#define TOPIC_DATA   "tinyml/har/practica-js-7319/data"
#define TOPIC_ACK    "tinyml/har/practica-js-7319/ack"
#define TOPIC_RESULT "tinyml/har/practica-js-7319/result"
#define TOPIC_STATUS "tinyml/har/practica-js-7319/status"

WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
Adafruit_SSD1306 oled(128, 64, &Wire, -1);

// Tiempos de procesamiento en microsegundos
uint32_t ultimoFeaturesUs = 0;
uint32_t ultimoInferenceUs = 0;
uint32_t ultimoTotalUs = 0;

unsigned long ultimoIntentoWiFi = 0;

// Una ventana: 128 muestras x 6 canales
float ventana[128][6];
float caracteristicas[har::NUM_FEATURES];

// Cada bit representa un fragmento recibido
uint16_t fragmentos = 0;
int recibidos = 0;
int ventanaActual = -1;
int ultimaVentana = -1;
int ultimaClase = -1;

unsigned long ultimoIntento = 0;
unsigned long tiempoLED = 0;
unsigned long tiempoBoton = 0;
bool botonAnterior = HIGH;

void mostrar(const char* linea1, const char* linea2 = "") {
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 0);
  oled.println("TinyML - HAR");
  oled.drawLine(0, 12, 127, 12, SSD1306_WHITE);
  oled.setCursor(0, 25);
  oled.println(linea1);
  oled.setCursor(0, 42);
  oled.println(linea2);
  oled.display();
}

void confirmarFragmento(int id, int chunk) {

    char mensaje[100];

    snprintf(
        mensaje,
        sizeof(mensaje),
        "{\"window_id\":%d,\"chunk\":%d}",
        id,
        chunk
    );

    bool enviado = mqtt.publish(TOPIC_ACK, mensaje);

    if (!enviado) {
        Serial.printf(
            "ERROR ACK: fragmento %d, MQTT=%d, WiFi=%d\n",
            chunk + 1,
            mqtt.state(),
            WiFi.status()
        );
    }
}


void publicarResultado(int id, int clase) {
  char mensaje[256];

  snprintf(
    mensaje,
    sizeof(mensaje),
    "{\"window_id\":%d,"
    "\"class_id\":%d,"
    "\"activity\":\"%s\","
    "\"features_us\":%lu,"
    "\"inference_us\":%lu,"
    "\"total_us\":%lu}",
    id,
    clase,
    har::activityName(clase),
    (unsigned long)ultimoFeaturesUs,
    (unsigned long)ultimoInferenceUs,
    (unsigned long)ultimoTotalUs
  );

  mqtt.publish(TOPIC_RESULT, mensaje);
}



void procesarVentana(int id) {
  Serial.println("\nVentana completa: 128 muestras");

  // 1. Medir extracción de características
  uint32_t inicio = micros();

  har::extractFeatures(ventana, caracteristicas);

  ultimoFeaturesUs = micros() - inicio;

  // 2. Medir inferencia del árbol
  inicio = micros();

  int clase = har::predict(caracteristicas);

  ultimoInferenceUs = micros() - inicio;

  // 3. Calcular procesamiento total
  ultimoTotalUs = ultimoFeaturesUs + ultimoInferenceUs;

  // 4. Mostrar resultados en monitor serial
  Serial.println("\n===== RESULTADO TINYML =====");

  Serial.print("Actividad: ");
  Serial.println(har::activityName(clase));

  Serial.printf(
    "Extraccion: %lu us (%.3f ms)\n",
    (unsigned long)ultimoFeaturesUs,
    ultimoFeaturesUs / 1000.0f
  );

  Serial.printf(
    "Inferencia: %lu us (%.3f ms)\n",
    (unsigned long)ultimoInferenceUs,
    ultimoInferenceUs / 1000.0f
  );

  Serial.printf(
    "Tiempo total: %lu us (%.3f ms)\n",
    (unsigned long)ultimoTotalUs,
    ultimoTotalUs / 1000.0f
  );

  Serial.println("===========================\n");

  // 5. Mostrar resultado en OLED
  mostrar("Actividad detectada:",
          har::activityName(clase));

  oled.setCursor(0, 54);
  oled.printf("ML: %.3f ms",
              ultimoInferenceUs / 1000.0f);
  oled.display();

  // 6. Encender LED
  digitalWrite(LED_PIN, HIGH);
  tiempoLED = millis();

  ultimaVentana = id;
  ultimaClase = clase;

  // 7. Publicar resultado por MQTT
  publicarResultado(id, clase);
  mqtt.publish(TOPIC_STATUS, "done");

  // 8. Reiniciar recepción
  ventanaActual = -1;
  fragmentos = 0;
  recibidos = 0;
}


void recibirMensaje(char* topic, byte* payload,
                    unsigned int longitud) {
  if (strcmp(topic, TOPIC_DATA) != 0) return;

  JsonDocument doc;
  if (deserializeJson(doc, payload, longitud)) {
    Serial.println("Error al leer JSON");
    return;
  }

  int id = doc["window_id"] | -1;
  int chunk = doc["chunk"] | -1;

  if (id < 0 || chunk < 0 || chunk >= 16) return;

  // Si se retransmite un fragmento ya procesado,
  // repetir la confirmacion sin inferir otra vez.
  if (id == ultimaVentana) {
    confirmarFragmento(id, chunk);
    if (chunk == 15) publicarResultado(id, ultimaClase);
    return;
  }

  // Una nueva ventana debe comenzar en el chunk 0
  if (id != ventanaActual) {
    if (chunk != 0) return;

    ventanaActual = id;
    fragmentos = 0;
    recibidos = 0;
    mostrar("Recibiendo datos...", "0 / 16");
  }

  uint16_t bit = (uint16_t)(1u << chunk);

  if (!(fragmentos & bit)) {
    JsonArrayConst datos = doc["data"].as<JsonArrayConst>();

    if (datos.isNull() || datos.size() != 8) return;

    // Verificar las dimensiones antes de copiar
    for (int i = 0; i < 8; i++) {
      JsonArrayConst fila = datos[i].as<JsonArrayConst>();
      if (fila.isNull() || fila.size() != 6) return;
    }

    for (int i = 0; i < 8; i++) {
      JsonArrayConst fila = datos[i].as<JsonArrayConst>();

      for (int j = 0; j < 6; j++) {
        ventana[chunk * 8 + i][j] = fila[j].as<float>();
      }
    }

    fragmentos |= bit;
    recibidos++;

    Serial.printf("Fragmento %d/16 recibido\n", chunk + 1);

    char progreso[24];
    snprintf(progreso, sizeof(progreso),
             "%d / 16", recibidos);

    mostrar("Recibiendo datos...", progreso);
  }

  confirmarFragmento(id, chunk);

  // Todos los bits activos = 16 fragmentos recibidos
  if (fragmentos == 0xFFFF) {
    procesarVentana(id);
  }
}

void conectarMQTT() {
  String clientId = "wokwi-har-";
  clientId += String((uint32_t)esp_random(), HEX);

  if (mqtt.connect(clientId.c_str())) {
    mqtt.subscribe(TOPIC_DATA);
    mqtt.publish(TOPIC_STATUS, "ready");

    Serial.println("Conectado a HiveMQ");
    mostrar("MQTT conectado", "Esperando ventana");
  } else {
    Serial.print("Error MQTT: ");
    Serial.println(mqtt.state());
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(21, 22);
  if (!oled.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("Error OLED");
    while (true) delay(100);
  }

  mostrar("Conectando WiFi...");

  WiFi.begin("Wokwi-GUEST", "", 6);

  while (WiFi.status() != WL_CONNECTED) {
    delay(200);
  }

  Serial.println("WiFi conectado");

  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setBufferSize(2048);
  
  // Ampliar intervalo de mantenimiento de conexión
  mqtt.setKeepAlive(60);
  mqtt.setSocketTimeout(20);

  mqtt.setCallback(recibirMensaje);

  conectarMQTT();
}

void loop() {

    // 1. Comprobar WiFi
    if (WiFi.status() != WL_CONNECTED) {

        if (millis() - ultimoIntentoWiFi >= 5000) {
            ultimoIntentoWiFi = millis();

            Serial.printf(
                "WiFi desconectado. Estado: %d\n",
                WiFi.status()
            );

            mostrar("Sin conexion WiFi", "Reconectando...");

            WiFi.disconnect();
            WiFi.begin("Wokwi-GUEST", "", 6);
        }

        delay(10);
        return;
    }

    // 2. Comprobar MQTT
    if (!mqtt.connected()) {

        if (millis() - ultimoIntento >= 5000) {
            ultimoIntento = millis();

            Serial.printf(
                "Reconectando MQTT. Estado: %d\n",
                mqtt.state()
            );

            conectarMQTT();
        }

    } else {
        mqtt.loop();
    }

  // El pulsador reinicia la recepcion
  bool boton = digitalRead(BUTTON_PIN);

  if (boton == LOW && botonAnterior == HIGH &&
      millis() - tiempoBoton > 250) {

    tiempoBoton = millis();
    ventanaActual = -1;
    ultimaVentana = -1;
    fragmentos = 0;
    recibidos = 0;

    mostrar("Nueva prueba", "Esperando datos");
    mqtt.publish(TOPIC_STATUS, "ready");

    Serial.println("Nueva prueba solicitada");
  }

  botonAnterior = boton;

  if (tiempoLED != 0 && millis() - tiempoLED >= 800) {
    digitalWrite(LED_PIN, LOW);
    tiempoLED = 0;
  }
}
